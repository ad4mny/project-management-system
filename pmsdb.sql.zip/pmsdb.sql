-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 05, 2022 at 12:22 AM
-- Server version: 8.0.26
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigns`
--

CREATE TABLE `assigns` (
  `assignID` int NOT NULL,
  `taskID` int DEFAULT NULL,
  `userID` int DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assigns`
--

INSERT INTO `assigns` (`assignID`, `taskID`, `userID`, `log`) VALUES
(5, 5, 1, '2022/01/04 15:23:47 UTC'),
(6, 6, 1, '2022/01/04 15:35:29 UTC'),
(7, 6, 2, '2022/01/04 15:35:29 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `projectMembers`
--

CREATE TABLE `projectMembers` (
  `memberID` int NOT NULL,
  `projectID` int DEFAULT NULL,
  `userID` int DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projectMembers`
--

INSERT INTO `projectMembers` (`memberID`, `projectID`, `userID`, `log`) VALUES
(8, 4, 1, '2022/01/04 15:23:47 UTC'),
(9, 4, 3, '2022/01/04 15:23:47 UTC'),
(10, 5, 1, '2022/01/04 15:35:29 UTC'),
(11, 5, 3, '2022/01/04 15:35:29 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `projectID` int NOT NULL,
  `userID` int DEFAULT NULL,
  `projectName` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `projectDesc` text COLLATE utf8mb4_general_ci,
  `projectStartDate` date DEFAULT NULL,
  `projectEndDate` date DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`projectID`, `userID`, `projectName`, `projectDesc`, `projectStartDate`, `projectEndDate`, `log`) VALUES
(4, 2, 'Database System Assignment 1', 'Buat laaaaa', '2021-12-28', '2022-01-05', '2022/01/04 15:23:47 UTC'),
(5, 2, 'English Professional Mock IV', 'Buat iv rakan rakan', '2021-12-29', '2022-01-19', '2022/01/04 15:35:29 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `taskID` int NOT NULL,
  `projectID` int DEFAULT NULL,
  `taskName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`taskID`, `projectID`, `taskName`, `log`) VALUES
(5, 4, 'Buat ERD', '2022/01/04 15:23:47 UTC'),
(6, 5, 'Siapkan ucapan pengetua', '2022/01/04 15:35:29 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `teamID` int NOT NULL,
  `userID` int DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`teamID`, `userID`, `log`) VALUES
(7, 5, '2022/01/05 00:08:29 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int NOT NULL,
  `teamID` int DEFAULT NULL,
  `teamRequest` int DEFAULT NULL,
  `username` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstName` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastName` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `log` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `teamID`, `teamRequest`, `username`, `password`, `firstName`, `lastName`, `log`) VALUES
(1, NULL, NULL, 'adamz', 'bad8cedab5860854eddc0a21f31dc6eb', 'adam', 'zulkornain', '2022/01/03 18:12:38 UTC'),
(2, NULL, NULL, 'aiman', 'bad8cedab5860854eddc0a21f31dc6eb', 'aiman', 'mujab', '2022/01/03 18:12:38 UTC'),
(3, NULL, NULL, 'asraf', 'bad8cedab5860854eddc0a21f31dc6eb', 'asraf', 'jibam', '2022/01/03 18:12:38 UTC'),
(4, NULL, NULL, 'hamas', 'bad8cedab5860854eddc0a21f31dc6eb', 'hamas', 'mustaqim', '2022/01/03 18:12:38 UTC'),
(5, 7, 0, 'azri', 'bad8cedab5860854eddc0a21f31dc6eb', 'azri', 'marzuki', '2022/01/03 18:12:38 UTC'),
(6, NULL, NULL, 'bad', 'bad8cedab5860854eddc0a21f31dc6eb', 'badrul', 'salim', '2022/01/03 18:12:38 UTC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigns`
--
ALTER TABLE `assigns`
  ADD PRIMARY KEY (`assignID`),
  ADD KEY `taskID` (`taskID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `projectMembers`
--
ALTER TABLE `projectMembers`
  ADD PRIMARY KEY (`memberID`),
  ADD KEY `projectID` (`projectID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`projectID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`taskID`),
  ADD KEY `projectID` (`projectID`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`teamID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD KEY `users_ibfk_1` (`teamID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigns`
--
ALTER TABLE `assigns`
  MODIFY `assignID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `projectMembers`
--
ALTER TABLE `projectMembers`
  MODIFY `memberID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `projectID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `taskID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `teamID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assigns`
--
ALTER TABLE `assigns`
  ADD CONSTRAINT `assigns_ibfk_1` FOREIGN KEY (`taskID`) REFERENCES `tasks` (`taskID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assigns_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projectMembers`
--
ALTER TABLE `projectMembers`
  ADD CONSTRAINT `projectmembers_ibfk_1` FOREIGN KEY (`projectID`) REFERENCES `projects` (`projectID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `projectmembers_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`projectID`) REFERENCES `projects` (`projectID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`teamID`) REFERENCES `teams` (`teamID`) ON DELETE SET NULL ON UPDATE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
