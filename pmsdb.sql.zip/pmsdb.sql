-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 12, 2022 at 12:17 PM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id18225890_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigns`
--

CREATE TABLE `assigns` (
  `assignID` int(11) NOT NULL,
  `taskID` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assigns`
--

INSERT INTO `assigns` (`assignID`, `taskID`, `userID`, `log`) VALUES
(5, 5, 1, '2022/01/04 15:23:47 UTC'),
(11, 9, 3, '2022/01/08 00:19:36 UTC'),
(12, 9, 2, '2022/01/08 00:19:36 UTC'),
(13, 10, 3, '2022/01/08 00:19:36 UTC'),
(20, 17, 1, '2022/01/08 01:21:13 UTC'),
(21, 17, 2, '2022/01/08 01:21:13 UTC'),
(22, 17, 3, '2022/01/08 01:21:13 UTC'),
(23, 18, 1, '2022/01/08 01:21:13 UTC'),
(24, 18, 3, '2022/01/08 01:21:13 UTC'),
(25, 19, 2, '2022/01/08 01:21:13 UTC'),
(26, 20, 7, '2022/01/11 01:53:34 UTC'),
(27, 21, 8, '2022/01/11 01:53:34 UTC'),
(28, 21, 7, '2022/01/11 01:53:34 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `friendID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `requestID` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`friendID`, `userID`, `requestID`, `status`, `log`) VALUES
(1, 4, NULL, 0, NULL),
(2, 1, 2, 1, NULL),
(4, 1, 5, 1, NULL),
(5, 4, 1, 1, NULL),
(6, 6, 1, 1, NULL),
(7, 1, 4, 1, NULL),
(8, 7, 8, 1, NULL),
(9, 8, 7, 1, NULL),
(10, 7, 9, 1, NULL),
(11, 8, 9, 1, NULL),
(12, 9, 7, 1, NULL),
(13, 9, 8, 1, NULL),
(14, 7, 1, 1, NULL),
(15, 1, 7, 1, NULL),
(16, 8, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `taskID` int(11) NOT NULL,
  `workspaceID` int(11) DEFAULT NULL,
  `taskName` varchar(100) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`taskID`, `workspaceID`, `taskName`, `log`) VALUES
(5, 4, 'Buat ERD', '2022/01/04 15:23:47 UTC'),
(9, 10, 'Buat intro', '2022/01/08 00:19:36 UTC'),
(10, 10, 'Buat conclusion', '2022/01/08 00:19:36 UTC'),
(17, 14, 'sediakan buffet afi lapar', '2022/01/08 01:21:13 UTC'),
(18, 14, 'Meja kena tegak', '2022/01/08 01:21:13 UTC'),
(19, 14, 'Pintu tutup sabun jangan kutip', '2022/01/08 01:21:13 UTC'),
(20, 15, 'Introduction', '2022/01/11 01:53:34 UTC'),
(21, 15, 'Overview', '2022/01/11 01:53:34 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `teamID` int(11) NOT NULL,
  `workspaceID` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`teamID`, `workspaceID`, `userID`, `log`) VALUES
(8, 4, 1, '2022/01/04 15:23:47 UTC'),
(9, 4, 5, '2022/01/04 15:23:47 UTC'),
(24, 10, 2, '2022/01/08 00:19:36 UTC'),
(25, 10, 3, '2022/01/08 00:19:36 UTC'),
(26, 11, 3, '2022/01/08 00:26:20 UTC'),
(33, 14, 1, '2022/01/08 01:21:13 UTC'),
(34, 14, 3, '2022/01/08 01:21:13 UTC'),
(35, 14, 2, '2022/01/08 01:21:13 UTC'),
(36, 15, 9, '2022/01/11 01:53:34 UTC'),
(37, 15, 7, '2022/01/11 01:53:34 UTC'),
(38, 15, 8, '2022/01/11 01:53:34 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `firstName`, `lastName`, `log`) VALUES
(1, 'adam', 'bad8cedab5860854eddc0a21f31dc6eb', 'Adam', 'zulkornain', '2022/01/08 17:42:01 UTC'),
(2, 'aiman', 'bad8cedab5860854eddc0a21f31dc6eb', 'aiman', 'mujab', '2022/01/03 18:12:38 UTC'),
(3, 'asraf', 'bad8cedab5860854eddc0a21f31dc6eb', 'asraf', 'jibam', '2022/01/03 18:12:38 UTC'),
(4, 'hamas', 'bad8cedab5860854eddc0a21f31dc6eb', 'hamas', 'mustaqim', '2022/01/03 18:12:38 UTC'),
(5, 'azri', 'bad8cedab5860854eddc0a21f31dc6eb', 'azri', 'marzuki', '2022/01/03 18:12:38 UTC'),
(6, 'bad', 'bad8cedab5860854eddc0a21f31dc6eb', 'badrul', 'salim', '2022/01/03 18:12:38 UTC'),
(7, 'Mandx', '24775f4c046499d6494654258352495a', 'Alif', 'Aiman', '2022/01/11 01:13:23 UTC'),
(8, 'Arif joe', '8ff32489f92f33416694be8fdc2d4c22', 'Joe', 'Joe', '2022/01/11 01:13:55 UTC'),
(9, 'Hisham', '439de6e2eeea1c8438d2314b887185a1', 'Syed', 'Hisham', '2022/01/11 01:50:57 UTC');

-- --------------------------------------------------------

--
-- Table structure for table `workspaces`
--

CREATE TABLE `workspaces` (
  `workspaceID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `workspaceName` varchar(50) DEFAULT NULL,
  `workspaceDesc` text DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workspaces`
--

INSERT INTO `workspaces` (`workspaceID`, `userID`, `workspaceName`, `workspaceDesc`, `startDate`, `endDate`, `log`) VALUES
(4, 1, 'Database System Assignment 1', 'Buat laaaaa', '2021-12-28', '2022-01-05', '2022/01/04 15:23:47 UTC'),
(10, 1, 'Thesis Report Full', 'Buat psm sampai siap', '2022-01-06', '2022-01-07', '2022/01/08 00:19:36 UTC'),
(11, 1, 'Test BI', 'test', '2021-12-27', '2021-12-27', '2022/01/08 00:26:20 UTC'),
(14, 1, 'Project Makan Malam', 'makan malam bersama afi', '2022-01-08', '2022-01-09', '2022/01/08 01:21:13 UTC'),
(15, 9, 'Network Management assigment 1', 'Jdhdjshs', '2022-01-11', '2022-01-15', '2022/01/11 01:53:34 UTC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigns`
--
ALTER TABLE `assigns`
  ADD PRIMARY KEY (`assignID`),
  ADD KEY `taskID` (`taskID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`friendID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `requestID` (`requestID`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`taskID`),
  ADD KEY `projectID` (`workspaceID`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`teamID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `workspaceID` (`workspaceID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD PRIMARY KEY (`workspaceID`),
  ADD KEY `userID` (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigns`
--
ALTER TABLE `assigns`
  MODIFY `assignID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `friendID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `taskID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `teamID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `workspaces`
--
ALTER TABLE `workspaces`
  MODIFY `workspaceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assigns`
--
ALTER TABLE `assigns`
  ADD CONSTRAINT `assigns_ibfk_1` FOREIGN KEY (`taskID`) REFERENCES `tasks` (`taskID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `assigns_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `friends`
--
ALTER TABLE `friends`
  ADD CONSTRAINT `friends_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `friends_ibfk_2` FOREIGN KEY (`requestID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`workspaceID`) REFERENCES `workspaces` (`workspaceID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`workspaceID`) REFERENCES `workspaces` (`workspaceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teams_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD CONSTRAINT `workspaces_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
